import React from "react";
import "./PokemonStyling.css"; 

function Pokemon({ data }) {
  return (
    <div className="pokemon-card">
      <h2>{data.name}</h2>
      <img
        src={data.sprites.front_default}
        alt={`Bild på ${data.name}`}
      />
      <p>
        Typ:{""}
        {data.types.map((typeInfo) => typeInfo.type.name).join(", ")}
      </p>
      <p>
        Vikt: {data.weight / 10} Kg
      </p>
      <p>
        Längd: {data.height / 10} M
      </p>
    </div>
  );
}

export default Pokemon;

