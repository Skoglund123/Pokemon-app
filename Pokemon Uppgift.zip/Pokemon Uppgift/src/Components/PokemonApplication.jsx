import React, { useState, useEffect } from "react";
import Pokemon from "./Pokemon";
import "./PokemonStyling.css";

function PokemonApplication() {
  const [pokemonList, setPokemonList] = useState([]);
  const [selectedPokemonUrl, setSelectedPokemonUrl] = useState("");
  const [pokemonData, setPokemonData] = useState(null);

  useEffect(() => {
    const fetchPokemonList = async () => {
      const response = await fetch("https://pokeapi.co/api/v2/pokemon?limit=151");
      const data = await response.json();
      setPokemonList(data.results);
    };
  
    fetchPokemonList();
  }, []);
  
  const fetchPokemonData = async () => {
    if (!selectedPokemonUrl) return;
  
    const response = await fetch(selectedPokemonUrl);
    const data = await response.json();
    setPokemonData(data);
  };
  

  return (
    <div className="container">
      <h1>Pokemon Application</h1>
      <div className="controls">
        <select onChange={(e) => setSelectedPokemonUrl(e.target.value)} defaultValue="">
          <option value="" disabled>
            Välj en Pokémon
          </option>
          {pokemonList.map((pokemon) => (
            <option key={pokemon.name} value={pokemon.url}>
              {pokemon.name}
            </option>
          ))}
        </select>
        <button onClick={fetchPokemonData}>Hämta Pokémon</button>
      </div>
      {pokemonData && <Pokemon data={pokemonData} />}
    </div>
  );
}

export default PokemonApplication;

